-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 17, 2022 at 02:02 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pozoriste`
--

-- --------------------------------------------------------

--
-- Table structure for table `glumac`
--

CREATE TABLE `glumac` (
  `id_glumac` int(11) NOT NULL,
  `id_trupe` int(11) NOT NULL,
  `ime` varchar(30) DEFAULT NULL,
  `prezime` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `glumac`
--

INSERT INTO `glumac` (`id_glumac`, `id_trupe`, `ime`, `prezime`) VALUES
(1, 1, 'Aleksandar', 'Mihajlovic'),
(2, 1, 'Radmila', 'Djordjevic'),
(3, 1, 'Ninoslav', 'Trajkovic'),
(4, 1, 'Zetica', 'Dejanovic'),
(5, 1, 'Nenad', 'Nedeljkovic'),
(6, 1, 'Tamara', 'Stosic'),
(7, 1, 'Jelena', 'Filipovic'),
(8, 1, 'Marko', 'Petricevic'),
(9, 2, 'Aleksandar', 'Marinkovic'),
(10, 2, 'Aleksandar', 'Mihailovic'),
(11, 2, 'Aleksandar', 'Krstic'),
(12, 2, 'Vesna', 'Josipovic'),
(13, 2, 'Vesna', 'Stankovic'),
(14, 2, 'Danilo', 'Petrovic'),
(15, 2, 'Dragana', 'Jovanovic'),
(16, 2, 'Katarina', 'Arsic'),
(17, 2, 'Katarina', 'Mitic Pavlovic'),
(18, 2, 'Stefan', 'Mladenovic'),
(19, 3, 'Aleksandra', 'Jankovic'),
(20, 3, 'Ana', 'Mandic'),
(21, 3, 'Anica', 'Dobra'),
(22, 3, 'Bojan', 'Zirovic'),
(23, 3, 'Branimir', 'Brstina'),
(24, 3, 'Branislav', 'Trifunovic'),
(25, 3, 'Gorica', 'Popovic'),
(26, 3, 'Gordan', 'Kicic'),
(27, 3, 'Vladislav', 'Mihailovic');

-- --------------------------------------------------------

--
-- Table structure for table `kreditnakartica`
--

CREATE TABLE `kreditnakartica` (
  `id_kartica` int(11) NOT NULL,
  `broj_kartice` varchar(20) DEFAULT NULL,
  `tip` varchar(30) DEFAULT NULL,
  `datum_isteka` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `kreditnakartica`
--

INSERT INTO `kreditnakartica` (`id_kartica`, `broj_kartice`, `tip`, `datum_isteka`) VALUES
(1, '123123123', 'Visa', '2025-07-12'),
(2, '356784567', 'Visa', '2024-11-02'),
(3, '024187645', 'Master', '2025-10-15'),
(4, '992571840', 'Master', '2026-02-19'),
(5, '379054081', 'Dina', '2023-12-25'),
(6, '28983716', 'Dina', '2025-04-17');

-- --------------------------------------------------------

--
-- Table structure for table `osoba`
--

CREATE TABLE `osoba` (
  `id_osoba` int(11) NOT NULL,
  `ime` varchar(30) NOT NULL,
  `prezime` varchar(30) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `osoba`
--

INSERT INTO `osoba` (`id_osoba`, `ime`, `prezime`, `password`) VALUES
(1, 'Admin', 'Admin', 'admin'),
(2, 'Jovana', 'Jovanovic', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `pozorisnikomad`
--

CREATE TABLE `pozorisnikomad` (
  `naziv` varchar(50) NOT NULL,
  `id_producent` int(11) NOT NULL,
  `id_trupe` int(11) NOT NULL,
  `br_scena` int(11) DEFAULT NULL,
  `br_cinova` int(11) DEFAULT NULL,
  `opis_komada` longtext DEFAULT NULL,
  `zanr` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pozorisnikomad`
--

INSERT INTO `pozorisnikomad` (`naziv`, `id_producent`, `id_trupe`, `br_scena`, `br_cinova`, `opis_komada`, `zanr`) VALUES
('Ana Karenjina', 2, 2, 20, 47, 'U Ani Karenjini Tolstoj je dao izuzetnu psiholosku analizu ljudske duse, vrlo duboko i snazno, \r\ns realizmom umetnickog opisivanja koji dosad nismo imali', 'drama'),
('Crvenkapa', 3, 1, 6, 14, 'U predstavi se sa decom druze braca Grim, koji pokusavaju, uz deciju pomoc, da napisu bajku \"Crvenkapa\". \r\nDa li je Crvenkapa stvarno Crvenkapa ili je Zutokapa, dali je Vuk stvarno tako zao ili je on jedna smotana kukavica...', 'decija predstava'),
('Dervis i smrt', 1, 1, 16, 35, '„Derviš i smrt“ je roman koji je podeljen na dva dela. Prvi sadrži devet, a drugi sedam \r\npoglavlja. Svako od tih poglavlja započinje ulomkom iz Kurana, ajetom, koji najavljuje temu poglavlja. Zadnje poglavlje \r\npočinje istim ajetom kojim počinje i prvo poglavlje, čime je postignuta ciklička struktura romana gde je završetak ujedno \r\ni početak. Glavni lik je pripovedač koji pripoveda u prvom licu i unutarnjim monolozima izražava svoja razmišljanja o životu. \r\nReč je o njegovoj ispovesti koja je zapisana neposredno pre smrti.', 'drama'),
('Detroit', 4, 3, 15, 25, 'Komad DETROIT kroz pricu o komsijskim odnosima dva para – cije se stalezne i kulturne razlike, malogradjanske \r\n stege i zelje za slobodom nalaze u sukobu – prikazuje promene izazvane propadanjem sistema vrednosti Sjedinjenih Americkih Drzava danas.', 'drama'),
('Gospodja ministarka', 5, 2, 15, 30, 'Reditelj je iz petnih žila uspeo da napravi predstavu koja se nece gledati samo danas, \r\n vec o koji ce se pricati kao o Ozaloscenoj porodici, Sumnjivom licu,...', 'komedija'),
('Karolina Nojber', 5, 3, 12, 28, 'Uprkos tome što govori o desavanjima sa sredine 18. veka, zahvaljujusi svojoj sirini i \r\n univerzalnosti, ova drama nosi pecat aktuelnosti i predstavlja savremenu drustvenu satiru.', 'drama'),
('Necista krv', 6, 1, 15, 27, 'Necista krv je prirodan nastavak mojih  interesovanja kao autorke. Sve su te junakinje tragicno zavrsile. \r\n Sofka je jedna od njih. Medjutim, Sofkina tragedija je nesto drugacija. Ono sto je razlikuje od svih mojih dosadasnjih junakinja \r\n jeste to što se njena prica ne završava tragicnom smrcu vec tragicnim zivotom.', 'drama'),
('Skola za zene', 7, 3, 13, 27, 'U svojoj najmanje izvodjenoj komediji „Skola za zene“ Z. B. P. Molijer bavi se pitanjem \r\n odnosa prema zeni.', 'komedija'),
('Zlatokosa', 6, 3, 6, 10, 'U našoj adaptaciji bajke „Zlatokosa“ istina se nikada ne može sakriti, baš kao i u običnom životu! \r\nZatočena princeza svake godine na svoj rođendan na nebu vidi čarobne zvezde.', 'decija predstava');

-- --------------------------------------------------------

--
-- Table structure for table `pozoriste`
--

CREATE TABLE `pozoriste` (
  `id_pozoriste` int(11) NOT NULL,
  `naziv_pozorista` varchar(30) DEFAULT NULL,
  `adresa` varchar(30) DEFAULT NULL,
  `kontakt_telefon` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pozoriste`
--

INSERT INTO `pozoriste` (`id_pozoriste`, `naziv_pozorista`, `adresa`, `kontakt_telefon`) VALUES
(1, 'Pozoriste Bora Stankovic', 'Narodnog Heroja 1 Vranje', ' 017 400009'),
(2, 'Narodno pozoriste Nis', 'Sinđelićev trg 12 Niš', ' 018 527371'),
(3, 'Atelje 212', 'Svetogorska 21 Beograd ', ' 011 3246146');

-- --------------------------------------------------------

--
-- Table structure for table `predstava`
--

CREATE TABLE `predstava` (
  `id_predstava` int(11) NOT NULL,
  `id_repertoar` int(11) NOT NULL,
  `naziv` varchar(50) NOT NULL,
  `datum_odrzavanja` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `br_slobodnih_mesta` int(11) DEFAULT NULL,
  `cena_ulaznice` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `predstava`
--

INSERT INTO `predstava` (`id_predstava`, `id_repertoar`, `naziv`, `datum_odrzavanja`, `br_slobodnih_mesta`, `cena_ulaznice`) VALUES
(1, 1, 'Ana Karenjina', '2022-01-20 19:00:00', 200, 350),
(2, 1, 'Ana Karenjina', '2022-01-18 19:30:00', 200, 350),
(3, 1, 'Necista krv', '2022-01-19 18:00:00', 250, 350),
(4, 2, 'Necista krv', '2022-01-21 19:00:00', 350, 450),
(5, 4, 'Karolina Nojber', '2022-01-20 18:15:00', 350, 400),
(6, 3, 'Necista krv', '2022-01-25 19:15:00', 300, 400),
(7, 5, 'Detroit', '2022-01-26 20:00:00', 250, 400),
(8, 9, 'Detroit', '2022-01-16 18:08:04', 248, 350),
(9, 9, 'Crvenkapa', '2021-12-25 10:30:00', 200, 250);

-- --------------------------------------------------------

--
-- Table structure for table `pretplatnik`
--

CREATE TABLE `pretplatnik` (
  `id_pretplatnik` int(11) NOT NULL,
  `id_kartica` int(11) NOT NULL,
  `adresa` varchar(30) DEFAULT NULL,
  `kontakt_telefon` varchar(20) DEFAULT NULL,
  `ime` varchar(30) DEFAULT NULL,
  `prezime` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pretplatnik`
--

INSERT INTO `pretplatnik` (`id_pretplatnik`, `id_kartica`, `adresa`, `kontakt_telefon`, `ime`, `prezime`) VALUES
(1, 1, 'Obilicev Venac 12 Nis', '063567229', 'Marija', 'Vukcevic'),
(2, 2, 'Somborska 23 Nis', '069109554', 'Sandra', 'Denic'),
(3, 3, 'Prizrenska 4 Vranje', '062868900', 'Jana', 'Savic'),
(4, 4, 'Bore Stankovica 10 Beograd', '061005042', 'Darko', 'Milic'),
(5, 5, 'Bulevar Vojvode Misica  48 Beo', '064798653', 'Luka', 'Jokic'),
(6, 6, 'Bulevar Nemanjica 70 Nis', '063557521', 'Petar', 'Petrovic');

-- --------------------------------------------------------

--
-- Table structure for table `producent`
--

CREATE TABLE `producent` (
  `id_producent` int(11) NOT NULL,
  `ime` varchar(30) DEFAULT NULL,
  `prezime` varchar(30) DEFAULT NULL,
  `dostignuca` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `producent`
--

INSERT INTO `producent` (`id_producent`, `ime`, `prezime`, `dostignuca`) VALUES
(1, 'Jug', 'Radivojevic', '73 pozorišna komada, direktor Beogradskog dramskog pozorišta'),
(2, 'Kokan', ' Mladenovic', 'Uspeh njegovih predstava leži u sjajno dramatizovanim i adaptiranim tekstovima, \r\nsa odlično odabranim temama'),
(3, 'Andraš', 'Urban', 'direktor madjarskog gradskog pozorista Deze Kostolanji, osnivac internacionalnog pozorisnog \r\nfestivala Desiré Central Station'),
(4, 'Boris', 'Lijesevic', '30-ak predstava'),
(5, 'Tanja', 'Mandic Rigonat', 'Selektor Sterijinog pozorja za 2008. godine, selektor Medjunarodnog festivala \r\nmediteranskog pozorista Purgatorije u Tivtu'),
(6, 'Snezana', 'Trisic', 'Dobitnica je Sterijine nagrade za reziju, Blog je reziju predstave Ricard treci ocenio \r\nkao jednu od pet najboljih prosle sezone u Beogradu'),
(7, 'Natasa', 'Radulovic', 'Od 2011. godine clan je redakcije zvanicnog bloga BITEF-a,\r\nidejni je tvorac i umetnicki direktor beogradskog festivala savremene ruske drame');

-- --------------------------------------------------------

--
-- Table structure for table `repertoar`
--

CREATE TABLE `repertoar` (
  `id_repertoar` int(11) NOT NULL,
  `id_pozoriste` int(11) NOT NULL,
  `datum_pocetka` date DEFAULT NULL,
  `datum_zavrsetka` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `repertoar`
--

INSERT INTO `repertoar` (`id_repertoar`, `id_pozoriste`, `datum_pocetka`, `datum_zavrsetka`) VALUES
(1, 1, '2022-01-17', '2022-01-23'),
(2, 2, '2022-01-17', '2022-01-23'),
(3, 2, '2022-01-24', '2022-01-30'),
(4, 3, '2022-01-17', '2022-01-23'),
(5, 3, '2022-01-24', '2022-01-30'),
(6, 1, '2022-01-24', '2022-01-30'),
(7, 1, '2021-12-20', '2021-12-25'),
(8, 2, '2021-12-21', '2021-12-26'),
(9, 3, '2021-12-25', '2021-12-30');

-- --------------------------------------------------------

--
-- Table structure for table `rezervacija`
--

CREATE TABLE `rezervacija` (
  `br_rezervacije` int(11) NOT NULL,
  `id_salter` int(11) NOT NULL,
  `id_pretplatnik` int(11) NOT NULL,
  `id_predstava` int(11) NOT NULL,
  `datum_izvrsenja` date DEFAULT NULL,
  `ukupna_cena` float DEFAULT NULL,
  `br_osoba` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `rezervacija`
--

INSERT INTO `rezervacija` (`br_rezervacije`, `id_salter`, `id_pretplatnik`, `id_predstava`, `datum_izvrsenja`, `ukupna_cena`, `br_osoba`) VALUES
(1, 1, 6, 8, '2021-12-21', 700, 2);

-- --------------------------------------------------------

--
-- Table structure for table `salter`
--

CREATE TABLE `salter` (
  `id_salter` int(11) NOT NULL,
  `id_pozoriste` int(11) NOT NULL,
  `radno_vreme` varchar(30) DEFAULT NULL,
  `ime_radnika` varchar(30) DEFAULT NULL,
  `br_saltera` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `salter`
--

INSERT INTO `salter` (`id_salter`, `id_pozoriste`, `radno_vreme`, `ime_radnika`, `br_saltera`) VALUES
(1, 1, '10h-22h', 'Ana Anic', 15),
(2, 1, '8h-17h', 'Sara Savic', 17),
(3, 1, '8h-17h', 'Marko Markovic', 21),
(4, 2, '8-18h', 'Sanja Sakic', 9),
(5, 2, '10-20h', 'Mia Milic', 10),
(6, 2, '10-20h', 'Aleksa Mikic', 11),
(7, 3, '10-21h', 'Aleksa Lukic', 1),
(8, 3, '8h-17h', 'Lena Lazic', 2),
(9, 3, '8h-17h', 'Lazar Lazic', 5);

-- --------------------------------------------------------

--
-- Table structure for table `trupa`
--

CREATE TABLE `trupa` (
  `id_trupe` int(11) NOT NULL,
  `br_clanova` int(11) DEFAULT NULL,
  `naziv_trupe` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `trupa`
--

INSERT INTO `trupa` (`id_trupe`, `br_clanova`, `naziv_trupe`) VALUES
(1, 8, 'Vranjsko pozoriste'),
(2, 10, 'Nisko pozoriste'),
(3, 9, 'Beogradsko pozoriste');

-- --------------------------------------------------------

--
-- Table structure for table `uloga`
--

CREATE TABLE `uloga` (
  `id_uloga` int(11) NOT NULL,
  `id_glumac` int(11) NOT NULL,
  `naziv` varchar(50) NOT NULL,
  `naziv_uloge` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `uloga`
--

INSERT INTO `uloga` (`id_uloga`, `id_glumac`, `naziv`, `naziv_uloge`) VALUES
(1, 8, 'Necista krv', 'Hadzi Toma'),
(2, 2, 'Necista krv', 'Cona'),
(3, 7, 'Necista krv', 'Sofka'),
(4, 4, 'Necista krv', 'Tasana'),
(5, 6, 'Necista krv', 'Andja'),
(6, 3, 'Necista krv', 'Nikolca'),
(7, 5, 'Necista krv', 'Marko'),
(8, 1, 'Necista krv', 'gazda Rista'),
(9, 16, 'Ana Karenjina', 'Ana Karenjina'),
(10, 9, 'Ana Karenjina', 'Grof Aleksej Vronski'),
(11, 10, 'Ana Karenjina', 'Gnez Stepan Oblonski'),
(12, 11, 'Ana Karenjina', 'Grof Aleksije Karenj'),
(13, 12, 'Ana Karenjina', 'Kneginja Darja Oblon'),
(14, 13, 'Ana Karenjina', 'Kneginja Jekatarina '),
(15, 14, 'Ana Karenjina', 'Konstantin Ljevin'),
(16, 15, 'Ana Karenjina', 'Kneginja Jelisaveta '),
(17, 17, 'Ana Karenjina', 'Grofica Vronski'),
(18, 18, 'Ana Karenjina', 'Sergej Serjoza Karen'),
(19, 19, 'Karolina Nojber', 'Karolina Nojber'),
(20, 20, 'Karolina Nojber', 'Gospođa Gotšed'),
(21, 21, 'Karolina Nojber', 'Margareta Hofman'),
(22, 22, 'Karolina Nojber', 'Johan Nojber'),
(23, 23, 'Karolina Nojber', 'Johan Gotšed'),
(24, 24, 'Karolina Nojber', 'Otac'),
(25, 26, 'Karolina Nojber', 'Špigel Berg'),
(26, 27, 'Karolina Nojber', 'Seljak');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `glumac`
--
ALTER TABLE `glumac`
  ADD PRIMARY KEY (`id_glumac`),
  ADD KEY `FK_pripada` (`id_trupe`);

--
-- Indexes for table `kreditnakartica`
--
ALTER TABLE `kreditnakartica`
  ADD PRIMARY KEY (`id_kartica`);

--
-- Indexes for table `osoba`
--
ALTER TABLE `osoba`
  ADD PRIMARY KEY (`id_osoba`);

--
-- Indexes for table `pozorisnikomad`
--
ALTER TABLE `pozorisnikomad`
  ADD PRIMARY KEY (`naziv`),
  ADD KEY `FK_glumi` (`id_trupe`),
  ADD KEY `FK_rezira` (`id_producent`);

--
-- Indexes for table `pozoriste`
--
ALTER TABLE `pozoriste`
  ADD PRIMARY KEY (`id_pozoriste`);

--
-- Indexes for table `predstava`
--
ALTER TABLE `predstava`
  ADD PRIMARY KEY (`id_predstava`),
  ADD UNIQUE KEY `predstava_info` (`naziv`,`datum_odrzavanja`),
  ADD KEY `FK_sadrzi` (`id_repertoar`);

--
-- Indexes for table `pretplatnik`
--
ALTER TABLE `pretplatnik`
  ADD PRIMARY KEY (`id_pretplatnik`),
  ADD KEY `FK_poseduje` (`id_kartica`);

--
-- Indexes for table `producent`
--
ALTER TABLE `producent`
  ADD PRIMARY KEY (`id_producent`);

--
-- Indexes for table `repertoar`
--
ALTER TABLE `repertoar`
  ADD PRIMARY KEY (`id_repertoar`),
  ADD KEY `FK_nudi` (`id_pozoriste`);

--
-- Indexes for table `rezervacija`
--
ALTER TABLE `rezervacija`
  ADD PRIMARY KEY (`br_rezervacije`),
  ADD KEY `FK_za` (`id_predstava`),
  ADD KEY `FK_rezervise` (`id_pretplatnik`),
  ADD KEY `FK_vrsi` (`id_salter`);

--
-- Indexes for table `salter`
--
ALTER TABLE `salter`
  ADD PRIMARY KEY (`id_salter`),
  ADD KEY `FK_ima` (`id_pozoriste`);

--
-- Indexes for table `trupa`
--
ALTER TABLE `trupa`
  ADD PRIMARY KEY (`id_trupe`);

--
-- Indexes for table `uloga`
--
ALTER TABLE `uloga`
  ADD PRIMARY KEY (`id_uloga`),
  ADD KEY `FK_igra` (`id_glumac`),
  ADD KEY `FK_u` (`naziv`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `osoba`
--
ALTER TABLE `osoba`
  MODIFY `id_osoba` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `glumac`
--
ALTER TABLE `glumac`
  ADD CONSTRAINT `FK_pripada` FOREIGN KEY (`id_trupe`) REFERENCES `trupa` (`id_trupe`);

--
-- Constraints for table `pozorisnikomad`
--
ALTER TABLE `pozorisnikomad`
  ADD CONSTRAINT `FK_glumi` FOREIGN KEY (`id_trupe`) REFERENCES `trupa` (`id_trupe`),
  ADD CONSTRAINT `FK_rezira` FOREIGN KEY (`id_producent`) REFERENCES `producent` (`id_producent`);

--
-- Constraints for table `predstava`
--
ALTER TABLE `predstava`
  ADD CONSTRAINT `FK_je` FOREIGN KEY (`naziv`) REFERENCES `pozorisnikomad` (`naziv`),
  ADD CONSTRAINT `FK_sadrzi` FOREIGN KEY (`id_repertoar`) REFERENCES `repertoar` (`id_repertoar`);

--
-- Constraints for table `pretplatnik`
--
ALTER TABLE `pretplatnik`
  ADD CONSTRAINT `FK_poseduje` FOREIGN KEY (`id_kartica`) REFERENCES `kreditnakartica` (`id_kartica`);

--
-- Constraints for table `repertoar`
--
ALTER TABLE `repertoar`
  ADD CONSTRAINT `FK_nudi` FOREIGN KEY (`id_pozoriste`) REFERENCES `pozoriste` (`id_pozoriste`);

--
-- Constraints for table `rezervacija`
--
ALTER TABLE `rezervacija`
  ADD CONSTRAINT `FK_rezervise` FOREIGN KEY (`id_pretplatnik`) REFERENCES `pretplatnik` (`id_pretplatnik`),
  ADD CONSTRAINT `FK_vrsi` FOREIGN KEY (`id_salter`) REFERENCES `salter` (`id_salter`),
  ADD CONSTRAINT `FK_za` FOREIGN KEY (`id_predstava`) REFERENCES `predstava` (`id_predstava`);

--
-- Constraints for table `salter`
--
ALTER TABLE `salter`
  ADD CONSTRAINT `FK_ima` FOREIGN KEY (`id_pozoriste`) REFERENCES `pozoriste` (`id_pozoriste`);

--
-- Constraints for table `uloga`
--
ALTER TABLE `uloga`
  ADD CONSTRAINT `FK_igra` FOREIGN KEY (`id_glumac`) REFERENCES `glumac` (`id_glumac`),
  ADD CONSTRAINT `FK_u` FOREIGN KEY (`naziv`) REFERENCES `pozorisnikomad` (`naziv`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
