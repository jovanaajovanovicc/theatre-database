/*==============================================================*/
/* DBMS name:      MySQL 5.0                                    */
/* Created on:     16.1.2022. 17:24:22                          */
/*==============================================================*/


drop table if exists Glumac;

drop table if exists KreditnaKartica;

drop table if exists PozorisniKomad;

drop table if exists Pozoriste;

drop table if exists Predstava;

drop table if exists Pretplatnik;

drop table if exists Producent;

drop table if exists Repertoar;

drop table if exists Rezervacija;

drop table if exists Salter;

drop table if exists Trupa;

drop table if exists Uloga;

/*==============================================================*/
/* Table: Glumac                                                */
/*==============================================================*/
create table Glumac
(
   id_glumac            int not null,
   id_trupe             int not null,
   ime                  varchar(30),
   prezime              varchar(30),
   primary key (id_glumac)
);

/*==============================================================*/
/* Table: KreditnaKartica                                       */
/*==============================================================*/
create table KreditnaKartica
(
   id_kartica           int not null,
   broj_kartice         varchar(20),
   tip                  varchar(30),
   datum_isteka         date,
   primary key (id_kartica)
);

/*==============================================================*/
/* Table: PozorisniKomad                                        */
/*==============================================================*/
create table PozorisniKomad
(
   naziv                varchar(50) not null,
   id_producent         int not null,
   id_trupe             int not null,
   br_scena             int,
   br_cinova            int,
   opis_komada          text,
   zanr                 varchar(30),
   primary key (naziv)
);

/*==============================================================*/
/* Table: Pozoriste                                             */
/*==============================================================*/
create table Pozoriste
(
   id_pozoriste         int not null,
   naziv_pozorista      varchar(30),
   adresa               varchar(30),
   kontakt_telefon      varchar(20),
   primary key (id_pozoriste)
);

/*==============================================================*/
/* Table: Predstava                                             */
/*==============================================================*/
create table Predstava
(
   id_predstava         int not null,
   id_repertoar         int not null,
   naziv                varchar(50) not null,
   datum_odrzavanja     datetime,
   br_slobodnih_mesta   int,
   cena_ulaznice        float,
   primary key (id_predstava)
);

/*==============================================================*/
/* Table: Pretplatnik                                           */
/*==============================================================*/
create table Pretplatnik
(
   id_pretplatnik       int not null,
   id_kartica           int not null,
   adresa               varchar(30),
   kontakt_telefon      varchar(20),
   ime                  varchar(30),
   prezime              varchar(30),
   primary key (id_pretplatnik)
);

/*==============================================================*/
/* Table: Producent                                             */
/*==============================================================*/
create table Producent
(
   id_producent         int not null,
   ime                  varchar(30),
   prezime              varchar(30),
   dostignuca           text,
   primary key (id_producent)
);

/*==============================================================*/
/* Table: Repertoar                                             */
/*==============================================================*/
create table Repertoar
(
   id_repertoar         int not null,
   id_pozoriste         int not null,
   datum_pocetka        date,
   datum_zavrsetka      date,
   primary key (id_repertoar)
);

/*==============================================================*/
/* Table: Rezervacija                                           */
/*==============================================================*/
create table Rezervacija
(
   br_rezervacije       int not null,
   id_salter            int not null,
   id_pretplatnik       int not null,
   id_predstava         int not null,
   datum_izvrsenja      date,
   ukupna_cena          float,
   br_osoba             int,
   primary key (br_rezervacije)
);

/*==============================================================*/
/* Table: Salter                                                */
/*==============================================================*/
create table Salter
(
   id_salter            int not null,
   id_pozoriste         int not null,
   radno_vreme          varchar(30),
   ime_radnika          varchar(30),
   br_saltera           int,
   primary key (id_salter)
);

/*==============================================================*/
/* Table: Trupa                                                 */
/*==============================================================*/
create table Trupa
(
   id_trupe             int not null,
   br_clanova           int,
   naziv_trupe          varchar(30),
   primary key (id_trupe)
);

/*==============================================================*/
/* Table: Uloga                                                 */
/*==============================================================*/
create table Uloga
(
   id_uloga             int not null,
   id_glumac            int not null,
   naziv                varchar(50) not null,
   naziv_uloge          varchar(20),
   primary key (id_uloga)
);

alter table Glumac add constraint FK_pripada foreign key (id_trupe)
      references Trupa (id_trupe) on delete restrict on update restrict;

alter table PozorisniKomad add constraint FK_glumi foreign key (id_trupe)
      references Trupa (id_trupe) on delete restrict on update restrict;

alter table PozorisniKomad add constraint FK_rezira foreign key (id_producent)
      references Producent (id_producent) on delete restrict on update restrict;

alter table Predstava add constraint FK_je foreign key (naziv)
      references PozorisniKomad (naziv) on delete restrict on update restrict;

alter table Predstava add constraint FK_sadrzi foreign key (id_repertoar)
      references Repertoar (id_repertoar) on delete restrict on update restrict;

alter table Pretplatnik add constraint FK_poseduje foreign key (id_kartica)
      references KreditnaKartica (id_kartica) on delete restrict on update restrict;

alter table Repertoar add constraint FK_nudi foreign key (id_pozoriste)
      references Pozoriste (id_pozoriste) on delete restrict on update restrict;

alter table Rezervacija add constraint FK_rezervise foreign key (id_pretplatnik)
      references Pretplatnik (id_pretplatnik) on delete restrict on update restrict;

alter table Rezervacija add constraint FK_vrsi foreign key (id_salter)
      references Salter (id_salter) on delete restrict on update restrict;

alter table Rezervacija add constraint FK_za foreign key (id_predstava)
      references Predstava (id_predstava) on delete restrict on update restrict;

alter table Salter add constraint FK_ima foreign key (id_pozoriste)
      references Pozoriste (id_pozoriste) on delete restrict on update restrict;

alter table Uloga add constraint FK_igra foreign key (id_glumac)
      references Glumac (id_glumac) on delete restrict on update restrict;

alter table Uloga add constraint FK_u foreign key (naziv)
      references PozorisniKomad (naziv) on delete restrict on update restrict;

